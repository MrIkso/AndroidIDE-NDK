.. cmake-module:: ../../Modules/FindMsys.cmake
