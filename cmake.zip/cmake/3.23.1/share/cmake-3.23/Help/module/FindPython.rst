.. cmake-module:: ../../Modules/FindPython.cmake
