.. cmake-module:: ../../Modules/FindGnuTLS.cmake
